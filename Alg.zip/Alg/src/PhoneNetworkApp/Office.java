package PhoneNetworkApp;

import GraphFramework.Vertex;

public class Office extends Vertex {
    
    public Office(String lable, boolean isVisited){
        super(lable, isVisited);
    }
    public Office() {
    }
}
